let oledTriangle = document.querySelector('.oled-triangle');
let cryptoTriangle = document.querySelector('.crypto-triangle')
let hiddenElements = [...document.querySelectorAll('.hidden-row')];
let shortDottedLine = document.querySelector('.short-dotted-line');
let longDottedLine = document.querySelector('.long-dotted-line')
let outerLineWithCircle = document.querySelector('.outer-line-with-circle');
let outerLineOnly = document.querySelector('.outer-line-only');
let navChilds = document.querySelectorAll('.nav-div-child-wrapper');
let navSubChilds = document.querySelectorAll('.nav-div-child')
let rightSideHeader = document.querySelector('.right-side-header')
let leftSideHeader = document.querySelector('.left-side-header')
let navCollapsingBtn = document.querySelector('.navCollapsingTab')
let sideBar = document.querySelector('.side-bar')
let users = document.querySelector('.users')
let switchWorkspace = document.querySelector('.switch-workspace')
let isAllHide;

console.log(leftSideHeader);

switchWorkspace.addEventListener('click' , (e)=>{
  switchWorkspace.classList.toggle('active')
  document.addEventListener('click' , (e)=>{
    if(!e.target.matches("[data-switchWorkspace]") && !e.target.matches("[data-swithcWorkspace-child]")){
      switchWorkspace.classList.remove('active')
      console.log(e.target);
    }
  })
  
})


users.addEventListener('click' , (e)=>{
  users.classList.toggle('active')
  document.addEventListener('click' , (e)=>{
    if(!e.target.matches("[data-users]") && !e.target.matches("[data-users-child]")){
      users.classList.remove('active')
      console.log('matched');
    }
  })
  
})

navCollapsingBtn.addEventListener('click' , ()=>{
  sideBar.classList.toggle('collapsed-side-bar');
  leftSideHeader.classList.toggle('collapsed-header')
})

let sideBarEls = document.querySelectorAll('.nav-project-div');

rightSideHeader.addEventListener('click' , (e)=>{
  rightSideHeader.classList.toggle('active')
  document.addEventListener('click' , (e)=>{

    if(!e.target.matches("[data-edit-drop-down-button]")){
      rightSideHeader.classList.remove('active')
    }
  })
})



  // console.log(childs);


  sideBarEls.forEach(element => {
    element.addEventListener('click' , (e)=>{
      if(sideBar.classList.contains('collapsed-side-bar')){
       sideBar.classList.remove('collapsed-side-bar')
       return
      }
    let nextSibling = e.target.nextElementSibling;
    nextSibling.classList.toggle('hide');

    let childrens =  [...nextSibling.children]

    childrens.forEach((child) =>{
      child.classList.remove('active')
    })
    
    })

  });

  navSubChilds.forEach(navChild => {
    navChild.addEventListener('click' , (e)=>{
      navChild.classList.toggle('active')
    })
  })


oledTriangle.addEventListener('click' , (e)=>{
  console.log('clicked');
  e.preventDefault()

  firstTriangleFunction()
  outerLineWithCircle.classList.toggle('hide')
  outerLineOnly.classList.add('decrease-height')
  outerLineWithCircle.classList.add('decrease-height')
  oledTriangle.classList.toggle('rotated');
  shortDottedLine.classList.add('hide')
  cryptoTriangle.classList.remove('rotated')

});

cryptoTriangle.addEventListener('click' , (e)=>{
  e.preventDefault()
  shortDottedLine.classList.toggle('hide')
  cryptoTriangle.classList.toggle('rotated')
  for(let i = 1; i < hiddenElements.length; i++){
    hiddenElements[i].classList.toggle('hide')
  }
  
  outerLineOnly.classList.toggle('decrease-height');
  outerLineWithCircle.classList.toggle('decrease-height')
})


function firstTriangleFunction(){

 isAllHide = hiddenElements.every((item) =>{
  return item.classList.contains('hide')
 })

 if(isAllHide === true){
  hiddenElements[0].classList.toggle('hide');
 }else{
  hiddenElements.forEach(item => {
    item.classList.add('hide')
  });

 }
}
